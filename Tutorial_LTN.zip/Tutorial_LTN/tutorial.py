'''
Abstract
Learn how to use the Logic Tensor Networks (LTN) framework to solve visual reasoning tasks on a dataset similar to Clevr. 
We will build upon the LTN tutorials and resources available on the https://github.com/tommasocarraro/LTNtorch/tree/main/tutorials

Content
Imports
Introduction
Data
LTN - Creation of the Knowledge Base
LTN - Training
Loading of pre-trained model (Alternative to step 5 and 6)
Querying of truth values for logical expressions
Performance Analysis
Question Answering Example
'''

# Requirements
!pip list | grep -E "numpy|scikit-image|scipy"

!conda install -c conda-forge scikit-image --yes

# Run this in a cell before your imports
!pip uninstall -y scikit-image
!pip install --no-cache-dir scikit-image

!pip install --upgrade --force-reinstall numpy scikit-image

# Run this in a cell before your imports
!pip uninstall -y scikit-image
!pip install --no-cache-dir scikit-image

#----------------------------------------------------------------------------------------------------
!pip install opencv-python
!pip install opencv-python-headless
!pip install LTNtorch
#----------------------------------------------------------------------------------------------------

# IMPORTS
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt 
import os
import pickle
from itertools import product 
import cv2
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
import ltn
import random 
import seaborn as sns
from collections import defaultdict 
from tqdm import tqdm 
from skimage.io import imshow
import logging; logging.basicConfig(level=logging.INFO)
from IPython.display import Image
import zipfile
import pickle

# -----------------------------------
# import helper functions
from helper_functions import *


'''
2) Introduction
With this tutorial we want to introduce bring together an archetypical framework and a benchmark in the field of 
Neuro Symbolic AI: LTN and a simplified version of the Clevr dataset that focuses on the visual components.

CLEVR is a 'diagnostic  dataset  that tests a range of visual reasoning abilities. It contains minimal biases 
and has detailed annotations describing the kind of reasoning each question requires.[...] [It can be used] 
to analyze a variety of modern visual reasoning systems, providing novel insights into their abilities and 
limitations.' ([CLEVR paper](https://arxiv.org/abs/1612.06890)) 
The [simplified version](https://github.com/nerdimite/neuro-symbolic-ai-soc) differs in that it contains a 2D 
scene with exactly 6 objects which can have one out of two shapes and one out of six different colours. 
(See chapter 3)

The LTN-solution is based on Multi-Class Multi-Label classification  and guarded quantifiers which have been 
introduced in a previous (https://github.com/logictensornetworks/logictensornetworks/blob/master/examples/multiclass_classification/multiclass-multilabel.ipynb) and 
[tutorial](https://github.com/logictensornetworks/logictensornetworks/blob/master/tutorials/2-grounding_connectives.ipynb) 
respectively. On this basis the LTN learns to identify absolute attributes of objects, their shape and colour, as well as 
the relative axiom 'left of', which expresses that an object is to the left of another object. The trained LTN is then 
used to evaluate the the truth values for logical expressions and answer questions about objects. The latler is visualized 
in the following figure.
'''

# Display the figure
img_path = "Figure 2 Simplified Clevr Detector and LTN.png"
Image(img_path, width=500)

#----------------------------------------------------------------------------------------------------
'''
3) Data
The dataset we are working with has undergone pre-processing using an object -detector to identify 
objects in the images. This pre-processing step allows us to focus on the application of the LTN. 
For a visualization of the output of the detector, please see the figure in section 2) in which the 
output is visualized as a red frame around objects.

The resulting dataframe contains the following information for each detected object:

Information about the original image:

The original image (stored in the 'original_image' column)
The identifier of the original image (stored in the 'image_name' column)
The output from the detector for each object:

The image of the object (stored in the 'object_image' column)
The identifier for the object (stored in the 'object_nb' column)
The position of the object center in the original image (stored in the 'object_center' column)
Finally, the detected objects need to be matched with their corresponding ground truth information 
provided in the Clevr data. The position of each detected object is compared with the object 
positions in the original data set. The ground truth information of the object closest to the 
detected one is assigned.

The color of the object (stored in the 'color' column)
The shape of the object (stored in the 'color' column)

'''
# Define data path - adjust this to your actual data location
data_preprocessed = "pre_processed_data/"  # Change this if your data is in a different folder

# Load the dataset
try:
    with zipfile.ZipFile(data_preprocessed + "dataset_on_bounding_box_level.zip", 'r') as zip_ref:
        zip_ref.extract("dataset_on_bounding_box_level", data_preprocessed)

    with open(data_preprocessed + "dataset_on_bounding_box_level", "rb") as fp:
        dataset_on_bounding_box_level = pickle.load(fp)
    
    print("Dataset loaded successfully!")
    summarize_imported_dataset_on_object_level(dataset_on_bounding_box_level)
    
except FileNotFoundError as e:
    print(f"Error: {e}")
    print("Please make sure:")
    print("1. dataset_on_bounding_box_level.zip exists in the specified path")
    print("2. The data_preprocessed variable points to the correct directory")
    print(f"Current data_preprocessed value: '{data_preprocessed}'")

#-----------------------------------------------------------------------------------------
# Visualizing a Random Example
example = np.random.randint(0, len(dataset_on_bounding_box_level))
visualize_example(dataset_on_bounding_box_level[example])
#-----------------------------------------------------------------------------------------
# Recreate your DataLoaders with the new function
ds_train, ds_test = create_pytorch_dataloaders(
    dataset_on_bounding_box_level, 
    batch_size=32, 
    split_thr=0.8,
    resize_shape=(36, 36)
)
#-----------------------------------------------------------------------------------------
print("Testing the new PyTorch DataLoader...")
for img_index, img_features, labels_shape, labels_color, location_feature in ds_train: 
    print(f"Batch - Image index shape: {img_index.shape}, type: {img_index.dtype}")
    print(f"Batch - Image features shape: {img_features.shape}, type: {img_features.dtype}")
    print(f"Batch - Labels shape: {labels_shape.shape}, type: {labels_shape.dtype}")
    print(f"Batch - Labels color: {labels_color.shape}, type: {labels_color.dtype}")
    print(f"Batch - Location feature: {location_feature.shape}, type: {location_feature.dtype}")
    
    # Verify these are PyTorch tensors
    print(f"Are all tensors PyTorch? Image index: {isinstance(img_index, torch.Tensor)}")
    print(f"Are all tensors PyTorch? Image features: {isinstance(img_features, torch.Tensor)}")
    
    break
#-----------------------------------------------------------------------------------------
ds_train, ds_test = create_pytorch_dataloaders(
    dataset_on_bounding_box_level, 
    batch_size=32, 
    split_thr=0.8,
    resize_shape=(36, 36)
)
#-----------------------------------------------------------------------------------------
print("Testing the new PyTorch DataLoader...")
for img_index, img_features, labels_shape, labels_color, location_feature in ds_train: 
    print(f"Batch - Image index shape: {img_index.shape}, type: {img_index.dtype}")
    print(f"Batch - Image features shape: {img_features.shape}, type: {img_features.dtype}")
    print(f"Batch - Labels shape: {labels_shape.shape}, type: {labels_shape.dtype}")
    print(f"Batch - Labels color: {labels_color.shape}, type: {labels_color.dtype}")
    print(f"Batch - Location feature: {location_feature.shape}, type: {location_feature.dtype}")
    
    # Verify these are PyTorch tensors
    print(f"Are all tensors PyTorch? Image index: {isinstance(img_index, torch.Tensor)}")
    print(f"Are all tensors PyTorch? Image features: {isinstance(img_features, torch.Tensor)}")
    
    break
#-----------------------------------------------------------------------------------------
'''
4) LTN - Creation of the Knowledge Bases
Note: As an alternative, step 6 can be completed instead of steps 4 and 5.

In the following cell, constants are defined. In our case each of them represent a class, a visual concept, that can be assigned to images of objects. This happens in a similar way as shown in Multi-Class Multi-Label classification example.

Definition of the building blocks for the axioms
The following code cells prepare the writing of the knowledge base. They contain definitions for 
constants, logical operators, and predicates. These are the 'building blocks' of the axioms that 
will make up the knowledge base.

(For information on knowledge bases in LTN please see this tutorial.)
'''
#-----------------------------------------------------------------------------------------
# Define constants
class_darkblue = ltn.Constant(torch.tensor([0]), trainable=False)
class_green = ltn.Constant(torch.tensor([1]), trainable=False)
class_red = ltn.Constant(torch.tensor([2]), trainable=False)
class_babyblue = ltn.Constant(torch.tensor([3]), trainable=False)
class_grey = ltn.Constant(torch.tensor([4]), trainable=False)
class_lightblue = ltn.Constant(torch.tensor([5]), trainable=False)
class_circle = ltn.Constant(torch.tensor([6]), trainable=False)
class_rectangle = ltn.Constant(torch.tensor([7]), trainable=False)

# define pairs of constants for easier handling
combis_colors_previous = [(a, b) for idx, a in enumerate([class_darkblue,class_green,class_red,class_babyblue, # provisional solution
                                                     class_grey,class_lightblue]) 
                          for b in [class_darkblue,class_green,class_red,class_babyblue,
                                                     class_grey,class_lightblue][idx + 1:]]
#-----------------------------------------------------------------------------------------
# In the following cell, logical operators get defined. The same definitions as in 
# Multi-Class Multi-Label classification example have been used with the addition of the 
# 'Exists' operator.
# Define logical operators
Not = ltn.Connective(ltn.fuzzy_ops.NotStandard())
And = ltn.Connective(ltn.fuzzy_ops.AndProd())
Or = ltn.Connective(ltn.fuzzy_ops.OrProbSum())
Implies = ltn.Connective(ltn.fuzzy_ops.ImpliesReichenbach())
Forall = ltn.Quantifier(ltn.fuzzy_ops.AggregPMeanError(p=2), quantifier="f")
Exists = ltn.Quantifier(ltn.fuzzy_ops.AggregPMean(p=2), quantifier="e")
sat_agg = ltn.fuzzy_ops.SatAgg()

#-----------------------------------------------------------------------------------------
# Diagnostic code - run this first
from helper_functions import CNN_simple
import torch.nn as nn

print(f"CNN_simple class: {CNN_simple}")
print(f"CNN_simple MRO: {CNN_simple.__mro__}")
print(f"Is CNN_simple a subclass of nn.Module? {issubclass(CNN_simple, nn.Module)}")

# Test instantiation
test_model = CNN_simple(8)
print(f"Model type: {type(test_model)}")
print(f"Is model instance of nn.Module? {isinstance(test_model, nn.Module)}")
#-----------------------------------------------------------------------------------------
# Now try to create the predicates again
absolute_object_attributes_nn = CNN_simple(8) 
absolute_object_attributes_predicate = ltn.Predicate(absolute_object_attributes_nn)

to_the_left_nn = Simple_keras_with_concatentation_left_of()
to_the_left_predicate = ltn.Predicate(to_the_left_nn)

print("SUCCESS: Models created with LTN predicates!")
#-----------------------------------------------------------------------------------------
# for easier handline create a dictionary with the nn and predicates 
predicates_and_nn = {'absolute_object_attributes_predicate': absolute_object_attributes_predicate,
                       'absolute_object_attributes_nn': absolute_object_attributes_nn,
                       'to_the_left_predicate':to_the_left_predicate ,
                       'to_the_left_nn':to_the_left_nn}
#-----------------------------------------------------------------------------------------
# Axioms Function for PyTorch
def axioms(img_index, img_features, labels_shape, labels_color, location_feature):
    # Define variables for absolute object attributes
    x = ltn.Variable("x", img_features)
    
    # Create masks for each color and shape
    mask_darkblue = labels_color == 0
    mask_green = labels_color == 1
    mask_red = labels_color == 2
    mask_babyblue = labels_color == 3
    mask_grey = labels_color == 4
    mask_lightblue = labels_color == 5
    mask_circle = labels_shape == 6
    mask_rectangle = labels_shape == 7
    
    # Apply masks to get subsets
    x_darkblue = ltn.Variable("x_darkblue", img_features[mask_darkblue]) if mask_darkblue.any() else ltn.Variable("x_darkblue", torch.empty(0, 3, 36, 36))
    x_green = ltn.Variable("x_green", img_features[mask_green]) if mask_green.any() else ltn.Variable("x_green", torch.empty(0, 3, 36, 36))
    x_red = ltn.Variable("x_red", img_features[mask_red]) if mask_red.any() else ltn.Variable("x_red", torch.empty(0, 3, 36, 36))
    x_babyblue = ltn.Variable("x_babyblue", img_features[mask_babyblue]) if mask_babyblue.any() else ltn.Variable("x_babyblue", torch.empty(0, 3, 36, 36))
    x_grey = ltn.Variable("x_grey", img_features[mask_grey]) if mask_grey.any() else ltn.Variable("x_grey", torch.empty(0, 3, 36, 36))
    x_lightblue = ltn.Variable("x_lightblue", img_features[mask_lightblue]) if mask_lightblue.any() else ltn.Variable("x_lightblue", torch.empty(0, 3, 36, 36))
    x_circle = ltn.Variable("x_circle", img_features[mask_circle]) if mask_circle.any() else ltn.Variable("x_circle", torch.empty(0, 3, 36, 36))
    x_rectangle = ltn.Variable("x_rectangle", img_features[mask_rectangle]) if mask_rectangle.any() else ltn.Variable("x_rectangle", torch.empty(0, 3, 36, 36))

    # [Rest of your pair creation logic remains the same...]
    
    axioms = [
        # ABSOLUTE ATTRIBUTE CASES - FIXED: No square brackets
        Forall(x_darkblue, absolute_object_attributes_predicate(x_darkblue, class_darkblue)), 
        Forall(x_green, absolute_object_attributes_predicate(x_green, class_green)),
        Forall(x_red, absolute_object_attributes_predicate(x_red, class_red)),
        Forall(x_babyblue, absolute_object_attributes_predicate(x_babyblue, class_babyblue)),
        Forall(x_grey, absolute_object_attributes_predicate(x_grey, class_grey)),
        Forall(x_lightblue, absolute_object_attributes_predicate(x_lightblue, class_lightblue)),
        Forall(x_circle, absolute_object_attributes_predicate(x_circle, class_circle)),
        Forall(x_rectangle, absolute_object_attributes_predicate(x_rectangle, class_rectangle)),
        
        # exclusivity axiom for shape - FIXED: No square brackets
        Forall(x, Not(And(absolute_object_attributes_predicate(x, class_circle), 
                          absolute_object_attributes_predicate(x, class_rectangle)))),
    ]

    # Add relative attribute cases only if we have valid pairs
    if len(valid_l_indices) > 0:
        axioms.extend([
            # FIXED: No square brackets
            Forall(ltn.diag(x_l_items, x_r_items), to_the_left_predicate(x_l_items)),
            Forall(ltn.diag(x_l_items, x_r_items), Not(to_the_left_predicate(x_r_items)))
        ])

    # exclusivity for colour - FIXED: No square brackets
    for combi in combis_colors_previous[::-1]: 
        axioms.append(Forall(x, Not(And(absolute_object_attributes_predicate(x, combi[0]), 
                                       absolute_object_attributes_predicate(x, combi[1])))))

    sat_level = And(*axioms)
    return sat_level.value

#-----------------------------------------------------------------------------------------
# Training loop example with proper PyTorch tensors
optimizer = torch.optim.Adam([
    {'params': absolute_object_attributes_nn.parameters()},
    {'params': to_the_left_nn.parameters()}
], lr=0.001)
#-----------------------------------------------------------------------------------------
# Now try to create the predicates again
absolute_object_attributes_nn = CNN_simple(8) 
absolute_object_attributes_predicate = ltn.Predicate(absolute_object_attributes_nn)

to_the_left_nn = Simple_keras_with_concatentation_left_of()
to_the_left_predicate = ltn.Predicate(to_the_left_nn)

print("SUCCESS: Models created with LTN predicates!")
#-----------------------------------------------------------------------------------------
# Test the axioms
for img_index, img_features, labels_shape, labels_color, location_feature in ds_train: 
    print("Initial sat level %.5f" % axioms(img_index, img_features, labels_shape, labels_color, location_feature))
    break
#-----------------------------------------------------------------------------------------

