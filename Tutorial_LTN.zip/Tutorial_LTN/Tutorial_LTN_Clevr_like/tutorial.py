'''

1) Learn how to use the Logic Tensor Networks (LTN) framework to solve visual reasoning tasks on a dataset similar to Clevr. 
We will build upon the LTN tutorials and resources available on the https://github.com/tommasocarraro/LTNtorch

Content
Imports
Introduction
Data
LTN - Creation of the Knowledge Base
LTN - Training
Loading of pre-trained model (Alternative to step 5 and 6)
Querying of truth values for logical expressions
Performance Analysis
Question Answering Example
'''

# Requirements
!pip list | grep -E "numpy|scikit-image|scipy"

!conda install -c conda-forge scikit-image --yes
!pip install --upgrade --force-reinstall numpy scikit-image

!pip install opencv-python
!pip install opencv-python-headless

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt 
import os
import pickle
from itertools import product 
import cv2
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
import ltn
import random 
import seaborn as sns
from collections import defaultdict 
from tqdm import tqdm 
from skimage.io import imshow
import logging; logging.basicConfig(level=logging.INFO)
from IPython.display import Image
import zipfile
# import zipfile

# -----------------------------------
# import helper functions
from helper_functions import *

'''
2) Introduction
With this tutorial we want to introduce and bring together an archetypical framework and a benchmark in the field of Neuro Symbolic AI: LTN and a simplified version of the Clevr dataset that focuses on the visual components.

CLEVR is a 'diagnostic dataset that tests a range of visual reasoning abilities. It contains minimal biases and has detailed annotations describing the kind of reasoning each question requires.[...] [It can be used] to analyze a variety of modern visual reasoning systems, providing novel insights into their abilities and limitations.' (CLEVR paper) The simplified version differs in that it contains a 2D scene with exactly 6 objects which can have one out of two shapes and one out of six different colours. (See chapter 3)

The LTN-solution is based on Multi-Class Multi-Label classification and guarded quantifiers which have been introduced in a previous example and tutorial respectively. On this basis the LTN learns to identify absolute attributes of objects, their shape and colour, as well as the relative axiom 'left of', which expresses that an object is to the left of another object. The trained LTN is then used to evaluate the the truth values for logical expressions and answer questions about objects. The latler is visualized in the following figure.
'''

# Display the figure
img_path = "Figure 2 Simplified Clevr Detector and LTN.png"
Image(img_path, width=500)


!pip install opencv-python
!pip install opencv-python-headless
!pip install LTNtorch

'''
3) Data
The dataset we are working with has undergone pre-processing using an object -detector to identify objects in the images. This pre-processing step allows us to focus on the application of the LTN. For a visualization of the output of the detector, please see the figure in section 2) in which the output is visualized as a red frame around objects.

The resulting dataframe contains the following information for each detected object:

Information about the original image:

The original image (stored in the 'original_image' column)
The identifier of the original image (stored in the 'image_name' column)
The output from the detector for each object:

The image of the object (stored in the 'object_image' column)
The identifier for the object (stored in the 'object_nb' column)
The position of the object center in the original image (stored in the 'object_center' column)
Finally, the detected objects need to be matched with their corresponding ground truth information provided in the Clevr data. The position of each detected object is compared with the object positions in the original data set. The ground truth information of the object closest to the detected one is assigned.

The color of the object (stored in the 'color' column)
The shape of the object (stored in the 'color' column)
'''

# Method 1: Extract the file first, then load it
with zipfile.ZipFile(data_preprocessed + "dataset_on_bounding_box_level.zip", 'r') as zip_ref:
    # Extract the pickle file (you might need to adjust the filename)
    zip_ref.extract("dataset_on_bounding_box_level", data_preprocessed)

# Define data path - adjust this to your actual data location
data_preprocessed = "pre_processed_data/"  # Change this if your data is in a different folder

# Load the dataset
try:
    with zipfile.ZipFile(data_preprocessed + "dataset_on_bounding_box_level.zip", 'r') as zip_ref:
        zip_ref.extract("dataset_on_bounding_box_level", data_preprocessed)

    with open(data_preprocessed + "dataset_on_bounding_box_level", "rb") as fp:
        dataset_on_bounding_box_level = pickle.load(fp)
    
    print("Dataset loaded successfully!")
    summarize_imported_dataset_on_object_level(dataset_on_bounding_box_level)
    
except FileNotFoundError as e:
    print(f"Error: {e}")
    print("Please make sure:")
    print("1. dataset_on_bounding_box_level.zip exists in the specified path")
    print("2. The data_preprocessed variable points to the correct directory")
    print(f"Current data_preprocessed value: '{data_preprocessed}'")

#-----------------------------------------------------------------------------------------
def create_pytorch_dataloaders(dataset, batch_size=32, split_thr=0.8, resize_shape=(36, 36)):
    """Create PyTorch DataLoaders from the dataset"""
    # Create dataset
    full_dataset = BoundingBoxDataset(dataset, resize_shape=resize_shape)
    
    # Calculate split
    split_samples = int(len(full_dataset) * split_thr)
    print(f"Splitting after {split_samples} samples into train + test")
    
    # Split dataset
    train_dataset, test_dataset = torch.utils.data.random_split(
        full_dataset, [split_samples, len(full_dataset) - split_samples]
    )
    
    # Create DataLoaders
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)
    
    print("PyTorch DataLoaders created successfully!")
    return train_loader, test_loader
#-----------------------------------------------------------------------------------------
# Visualizing a Random Example
example = np.random.randint(0, len(dataset_on_bounding_box_level))
visualize_example(dataset_on_bounding_box_level[example])
#-----------------------------------------------------------------------------------------
# Recreate your DataLoaders with the new function
ds_train, ds_test = create_pytorch_dataloaders(
    dataset_on_bounding_box_level, 
    batch_size=32, 
    split_thr=0.8,
    resize_shape=(36, 36)
)
#-----------------------------------------------------------------------------------------
print("Testing the new PyTorch DataLoader...")
for img_index, img_features, labels_shape, labels_color, location_feature in ds_train: 
    print(f"Batch - Image index shape: {img_index.shape}, type: {img_index.dtype}")
    print(f"Batch - Image features shape: {img_features.shape}, type: {img_features.dtype}")
    print(f"Batch - Labels shape: {labels_shape.shape}, type: {labels_shape.dtype}")
    print(f"Batch - Labels color: {labels_color.shape}, type: {labels_color.dtype}")
    print(f"Batch - Location feature: {location_feature.shape}, type: {location_feature.dtype}")
    
    # Verify these are PyTorch tensors
    print(f"Are all tensors PyTorch? Image index: {isinstance(img_index, torch.Tensor)}")
    print(f"Are all tensors PyTorch? Image features: {isinstance(img_features, torch.Tensor)}")
    
    break
#-----------------------------------------------------------------------------------------
# Create DataLoaders
ds_train,ds_test = from_bounding_boxes_list_to_ds_training_and_test(
    dataset_on_bounding_box_level,
    batch_size= 32,
    split_thr=0.8,
#    col_to_reshape = "object_image",
    resize_shape =(36, 36)
)
#-----------------------------------------------------------------------------------------
'''
4) LTN - Creation of the Knowledge Bases
Note: As an alternative, step 6 can be completed instead of steps 4 and 5.

In the following cell, constants are defined. In our case each of them represent a class, a visual concept, that can be assigned to images of objects. This happens in a similar way as shown in Multi-Class Multi-Label classification example.

Definition of the building blocks for the axioms
The following code cells prepare the writing of the knowledge base. They contain definitions for constants, logical operators, and predicates. These are the 'building blocks' of the axioms that will make up the knowledge base.

(For information on knowledge bases in LTN please see this tutorial.)
'''

# Define constants
class_darkblue = ltn.Constant(torch.tensor([0]), trainable=False)
class_green = ltn.Constant(torch.tensor([1]), trainable=False)
class_red = ltn.Constant(torch.tensor([2]), trainable=False)
class_babyblue = ltn.Constant(torch.tensor([3]), trainable=False)
class_grey = ltn.Constant(torch.tensor([4]), trainable=False)
class_lightblue = ltn.Constant(torch.tensor([5]), trainable=False)
class_circle = ltn.Constant(torch.tensor([6]), trainable=False)
class_rectangle = ltn.Constant(torch.tensor([7]), trainable=False)

# define pairs of constants for easier handling
combis_colors_previous = [(a, b) for idx, a in enumerate([class_darkblue,class_green,class_red,class_babyblue, # provisional solution
                                                     class_grey,class_lightblue]) 
                          for b in [class_darkblue,class_green,class_red,class_babyblue,
                                                     class_grey,class_lightblue][idx + 1:]]
#-----------------------------------------------------------------------------------------
# Define logical operators
Not = ltn.Connective(ltn.fuzzy_ops.NotStandard())
And = ltn.Connective(ltn.fuzzy_ops.AndProd())
Or = ltn.Connective(ltn.fuzzy_ops.OrProbSum())
Implies = ltn.Connective(ltn.fuzzy_ops.ImpliesReichenbach())
Forall = ltn.Quantifier(ltn.fuzzy_ops.AggregPMeanError(p=2), quantifier="f")
Exists = ltn.Quantifier(ltn.fuzzy_ops.AggregPMean(p=2), quantifier="e")
sat_agg = ltn.fuzzy_ops.SatAgg()
#-----------------------------------------------------------------------------------------
# Now try to create the predicates again
absolute_object_attributes_nn = CNN_simple(8) 
absolute_object_attributes_predicate = ltn.Predicate(absolute_object_attributes_nn)

to_the_left_nn = Simple_keras_with_concatentation_left_of()
to_the_left_predicate = ltn.Predicate(to_the_left_nn)

print("SUCCESS: Models created with LTN predicates!")
#-----------------------------------------------------------------------------------------
'''
In the following cell, predicates are defined.

These predicates are used to describe the characteristics and relationships of objects, the absolute and relative attributes.

The absolute attributes of an object, the color and shape, are defined using the 'absolute_object_attribute' predicate. This predicate is based on the visual information about the objects and thus build up on a Convolutional Neural Network.

The relative attributes of a pair of objects (x,y), the relationship "x is left of y," are defined using the 'to_the_left' predicate. This predicate is based on the location of the objects in the images and build up on a Neural Network.
'''
# for easier handline create a dictionary with the nn and predicates 
predicates_and_nn = {'absolute_object_attributes_predicate': absolute_object_attributes_predicate,
                       'absolute_object_attributes_nn': absolute_object_attributes_nn,
                       'to_the_left_predicate':to_the_left_predicate ,
                       'to_the_left_nn':to_the_left_nn}
#-----------------------------------------------------------------------------------------
### Axioms Function for PyTorch¶
def axioms(img_index, img_features, labels_shape, labels_color, location_feature):
    # Define variables for absolute object attributes
    x = ltn.Variable("x", img_features)
    
    # Create masks for each color and shape
    mask_darkblue = labels_color == 0
    mask_green = labels_color == 1
    mask_red = labels_color == 2
    mask_babyblue = labels_color == 3
    mask_grey = labels_color == 4
    mask_lightblue = labels_color == 5
    mask_circle = labels_shape == 6
    mask_rectangle = labels_shape == 7
    
    # Apply masks to get subsets
    x_darkblue = ltn.Variable("x_darkblue", img_features[mask_darkblue]) if mask_darkblue.any() else ltn.Variable("x_darkblue", torch.empty(0, 3, 36, 36))
    x_green = ltn.Variable("x_green", img_features[mask_green]) if mask_green.any() else ltn.Variable("x_green", torch.empty(0, 3, 36, 36))
    x_red = ltn.Variable("x_red", img_features[mask_red]) if mask_red.any() else ltn.Variable("x_red", torch.empty(0, 3, 36, 36))
    x_babyblue = ltn.Variable("x_babyblue", img_features[mask_babyblue]) if mask_babyblue.any() else ltn.Variable("x_babyblue", torch.empty(0, 3, 36, 36))
    x_grey = ltn.Variable("x_grey", img_features[mask_grey]) if mask_grey.any() else ltn.Variable("x_grey", torch.empty(0, 3, 36, 36))
    x_lightblue = ltn.Variable("x_lightblue", img_features[mask_lightblue]) if mask_lightblue.any() else ltn.Variable("x_lightblue", torch.empty(0, 3, 36, 36))
    x_circle = ltn.Variable("x_circle", img_features[mask_circle]) if mask_circle.any() else ltn.Variable("x_circle", torch.empty(0, 3, 36, 36))
    x_rectangle = ltn.Variable("x_rectangle", img_features[mask_rectangle]) if mask_rectangle.any() else ltn.Variable("x_rectangle", torch.empty(0, 3, 36, 36))

    # [Rest of your pair creation logic remains the same...]
    
    axioms = [
        # ABSOLUTE ATTRIBUTE CASES - FIXED: No square brackets
        Forall(x_darkblue, absolute_object_attributes_predicate(x_darkblue, class_darkblue)), 
        Forall(x_green, absolute_object_attributes_predicate(x_green, class_green)),
        Forall(x_red, absolute_object_attributes_predicate(x_red, class_red)),
        Forall(x_babyblue, absolute_object_attributes_predicate(x_babyblue, class_babyblue)),
        Forall(x_grey, absolute_object_attributes_predicate(x_grey, class_grey)),
        Forall(x_lightblue, absolute_object_attributes_predicate(x_lightblue, class_lightblue)),
        Forall(x_circle, absolute_object_attributes_predicate(x_circle, class_circle)),
        Forall(x_rectangle, absolute_object_attributes_predicate(x_rectangle, class_rectangle)),
        
        # exclusivity axiom for shape - FIXED: No square brackets
        Forall(x, Not(And(absolute_object_attributes_predicate(x, class_circle), 
                          absolute_object_attributes_predicate(x, class_rectangle)))),
    ]

    # Add relative attribute cases only if we have valid pairs
    if len(valid_l_indices) > 0:
        axioms.extend([
            # FIXED: No square brackets
            Forall(ltn.diag(x_l_items, x_r_items), to_the_left_predicate(x_l_items)),
            Forall(ltn.diag(x_l_items, x_r_items), Not(to_the_left_predicate(x_r_items)))
        ])

    # exclusivity for colour - FIXED: No square brackets
    for combi in combis_colors_previous[::-1]: 
        axioms.append(Forall(x, Not(And(absolute_object_attributes_predicate(x, combi[0]), 
                                       absolute_object_attributes_predicate(x, combi[1])))))

    sat_level = And(*axioms)
    return sat_level.value

#-----------------------------------------------------------------------------------------
# Training loop example with proper PyTorch tensors
optimizer = torch.optim.Adam([
    {'params': absolute_object_attributes_nn.parameters()},
    {'params': to_the_left_nn.parameters()}
], lr=0.001)
#-----------------------------------------------------------------------------------------
# Now try to create the predicates again
absolute_object_attributes_nn = CNN_simple(8) 
absolute_object_attributes_predicate = ltn.Predicate(absolute_object_attributes_nn)

to_the_left_nn = Simple_keras_with_concatentation_left_of()
to_the_left_predicate = ltn.Predicate(to_the_left_nn)

print("SUCCESS: Models created with LTN predicates!")
#-----------------------------------------------------------------------------------------

#-----------------------------------------------------------------------------------------


#-----------------------------------------------------------------------------------------
# Define the BoundingBoxDataset class first
class BoundingBoxDataset(Dataset):
    def __init__(self, dataset, resize_shape=(36, 36)):
        self.dataset = dataset
        self.resize_shape = resize_shape
        
    def __len__(self):
        return len(self.dataset)
    
    def __getitem__(self, idx):
        item = self.dataset[idx]
        
        # Resize image
        img_resized = cv2.resize(item['object_image'], dsize=self.resize_shape, interpolation=cv2.INTER_CUBIC)
        
        # Convert to PyTorch tensor and normalize - shape: [C, H, W]
        img_tensor = torch.tensor(img_resized, dtype=torch.float32).permute(2, 0, 1) / 255.0
        
        # Convert shape to numeric
        shape_label = 6 if item['shape'] == "circle" else 7
        
        # Return as PyTorch tensors
        return (
            torch.tensor(idx, dtype=torch.long),  # img_index
            img_tensor,                           # img_features
            torch.tensor(shape_label, dtype=torch.long),  # labels_shape
            torch.tensor(item['color'], dtype=torch.long),  # labels_color
            torch.tensor(item['object_center'], dtype=torch.float32)  # location_feature
        )
#-----------------------------------------------------------------------------------------

def create_pytorch_dataloaders(dataset, batch_size=32, split_thr=0.8, resize_shape=(36, 36)):
    """Create PyTorch DataLoaders from the dataset"""
    # Create dataset
    full_dataset = BoundingBoxDataset(dataset, resize_shape=resize_shape)
    
    # Calculate split
    split_samples = int(len(full_dataset) * split_thr)
    print(f"Splitting after {split_samples} samples into train + test")
    
    # Split dataset
    train_dataset, test_dataset = torch.utils.data.random_split(
        full_dataset, [split_samples, len(full_dataset) - split_samples]
    )
    
    # Create DataLoaders
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)
    
    print("PyTorch DataLoaders created successfully!")
    return train_loader, test_loader

# Visualizing a Random Example
example = np.random.randint(0, len(dataset_on_bounding_box_level))
visualize_example(dataset_on_bounding_box_level[example])

# Recreate your DataLoaders with the new function
ds_train, ds_test = create_pytorch_dataloaders(
    dataset_on_bounding_box_level, 
    batch_size=32, 
    split_thr=0.8,
    resize_shape=(36, 36)
)

#-----------------------------------------------------------------------------------------
# Simple model for left_of relation - PYTORCH VERSION
class Simple_keras_with_concatentation_left_of(nn.Module):
    def __init__(self):
        super(Simple_keras_with_concatentation_left_of, self).__init__()
        # Input: [batch_size, 6, 36, 36] - 2 images concatenated along channel dimension
        self.network = nn.Sequential(
            nn.Flatten(),
            nn.Linear(6 * 36 * 36, 128),
            nn.ELU(),
            nn.Linear(128, 64),
            nn.ELU(), 
            nn.Linear(64, 1),
            nn.Sigmoid()
        )
        
    def forward(self, x):
        # x shape: [batch_size, 6, 36, 36]
        x = x / 150.0  # Normalization
        return self.network(x)
#-----------------------------------------------------------------------------------------
print("Testing the new PyTorch DataLoader...")
for img_index, img_features, labels_shape, labels_color, location_feature in ds_train: 
    print(f"Batch - Image index shape: {img_index.shape}, type: {img_index.dtype}")
    print(f"Batch - Image features shape: {img_features.shape}, type: {img_features.dtype}")
    print(f"Batch - Labels shape: {labels_shape.shape}, type: {labels_shape.dtype}")
    print(f"Batch - Labels color: {labels_color.shape}, type: {labels_color.dtype}")
    print(f"Batch - Location feature: {location_feature.shape}, type: {location_feature.dtype}")
    
    # Verify these are PyTorch tensors
    print(f"Are all tensors PyTorch? Image index: {isinstance(img_index, torch.Tensor)}")
    print(f"Are all tensors PyTorch? Image features: {isinstance(img_features, torch.Tensor)}")
    
    break
#-----------------------------------------------------------------------------------------
# Define constants
class_darkblue = ltn.Constant(torch.tensor([0]), trainable=False)
class_green = ltn.Constant(torch.tensor([1]), trainable=False)
class_red = ltn.Constant(torch.tensor([2]), trainable=False)
class_babyblue = ltn.Constant(torch.tensor([3]), trainable=False)
class_grey = ltn.Constant(torch.tensor([4]), trainable=False)
class_lightblue = ltn.Constant(torch.tensor([5]), trainable=False)
class_circle = ltn.Constant(torch.tensor([6]), trainable=False)
class_rectangle = ltn.Constant(torch.tensor([7]), trainable=False)

# define pairs of constants for easier handling
combis_colors_previous = [(a, b) for idx, a in enumerate([class_darkblue,class_green,class_red,class_babyblue, # provisional solution
                                                     class_grey,class_lightblue]) 
                          for b in [class_darkblue,class_green,class_red,class_babyblue,
                                                     class_grey,class_lightblue][idx + 1:]]

# Define logical operators
Not = ltn.Connective(ltn.fuzzy_ops.NotStandard())
And = ltn.Connective(ltn.fuzzy_ops.AndProd())
Or = ltn.Connective(ltn.fuzzy_ops.OrProbSum())
Implies = ltn.Connective(ltn.fuzzy_ops.ImpliesReichenbach())
Forall = ltn.Quantifier(ltn.fuzzy_ops.AggregPMeanError(p=2), quantifier="f")
Exists = ltn.Quantifier(ltn.fuzzy_ops.AggregPMean(p=2), quantifier="e")
sat_agg = ltn.fuzzy_ops.SatAgg()

#-----------------------------------------------------------------------------------------
# Define the models directly in your notebook
class CNN_simple(nn.Module):
    def __init__(self, n_classes, img_size=[36, 36]):
        super(CNN_simple, self).__init__()
        self.conv_layers = nn.Sequential(
            nn.Conv2d(3, 16, 3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2),
            nn.Conv2d(16, 32, 3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2),
            nn.Conv2d(32, 64, 3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2),
        )
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(64 * 4 * 4, 128),
            nn.ReLU(),
            nn.Linear(128, n_classes)
        )
        # Add sigmoid activation for output
        self.sigmoid = nn.Sigmoid()
        
    def forward(self, x, class_label=None):
        """
        Modified to handle both single input (x) and dual input (x, class_label)
        LTN passes both image and class label as separate arguments
        """
        # Handle LTNObject input
        if hasattr(x, 'value'):
            x = x.value
        
        # If we get two arguments, only use the first one (image data)
        # The second argument (class_label) is for the predicate logic, not the model
        x = self.conv_layers(x)
        x = self.classifier(x)
        x = self.sigmoid(x)  # Ensure output is in [0, 1] range
        return x
        
class Simple_keras_with_concatentation_left_of(nn.Module):
    def __init__(self, input_size=36*36*3*2):
        super(Simple_keras_with_concatentation_left_of, self).__init__()
        self.network = nn.Sequential(
            nn.Flatten(),
            nn.Linear(input_size, 5),
            nn.ELU(),
            nn.Linear(5, 1),
            nn.Sigmoid()
        )
        
    def forward(self, x):
        x = x.view(x.size(0), -1)
        x = x / 150.0
        return self.network(x)
#-----------------------------------------------------------------------------------------
# Now try to create the predicates again
absolute_object_attributes_nn = CNN_simple(8) 
absolute_object_attributes_predicate = ltn.Predicate(absolute_object_attributes_nn)

to_the_left_nn = Simple_keras_with_concatentation_left_of()
to_the_left_predicate = ltn.Predicate(to_the_left_nn)

print("SUCCESS: Models created with LTN predicates!")


#-----------------------------------------------------------------------------------------
# for easier handline create a dictionary with the nn and predicates 
predicates_and_nn = {'absolute_object_attributes_predicate': absolute_object_attributes_predicate,
                       'absolute_object_attributes_nn': absolute_object_attributes_nn,
                       'to_the_left_predicate':to_the_left_predicate ,
                       'to_the_left_nn':to_the_left_nn}

#-----------------------------------------------------------------------------------------
## Updated Axioms Function for PyTorch
def axioms(img_index, img_features, labels_shape, labels_color, location_feature):
    # Define variables for absolute object attributes
    x = ltn.Variable("x", img_features)
    
    # Create masks for each color and shape
    mask_darkblue = labels_color == 0
    mask_green = labels_color == 1
    mask_red = labels_color == 2
    mask_babyblue = labels_color == 3
    mask_grey = labels_color == 4
    mask_lightblue = labels_color == 5
    mask_circle = labels_shape == 6
    mask_rectangle = labels_shape == 7
    
    # Apply masks to get subsets
    x_darkblue = ltn.Variable("x_darkblue", img_features[mask_darkblue]) if mask_darkblue.any() else ltn.Variable("x_darkblue", torch.empty(0, 3, 36, 36))
    x_green = ltn.Variable("x_green", img_features[mask_green]) if mask_green.any() else ltn.Variable("x_green", torch.empty(0, 3, 36, 36))
    x_red = ltn.Variable("x_red", img_features[mask_red]) if mask_red.any() else ltn.Variable("x_red", torch.empty(0, 3, 36, 36))
    x_babyblue = ltn.Variable("x_babyblue", img_features[mask_babyblue]) if mask_babyblue.any() else ltn.Variable("x_babyblue", torch.empty(0, 3, 36, 36))
    x_grey = ltn.Variable("x_grey", img_features[mask_grey]) if mask_grey.any() else ltn.Variable("x_grey", torch.empty(0, 3, 36, 36))
    x_lightblue = ltn.Variable("x_lightblue", img_features[mask_lightblue]) if mask_lightblue.any() else ltn.Variable("x_lightblue", torch.empty(0, 3, 36, 36))
    x_circle = ltn.Variable("x_circle", img_features[mask_circle]) if mask_circle.any() else ltn.Variable("x_circle", torch.empty(0, 3, 36, 36))
    x_rectangle = ltn.Variable("x_rectangle", img_features[mask_rectangle]) if mask_rectangle.any() else ltn.Variable("x_rectangle", torch.empty(0, 3, 36, 36))

    # [Rest of your pair creation logic remains the same...]
    
    axioms = [
        # ABSOLUTE ATTRIBUTE CASES - FIXED: No square brackets
        Forall(x_darkblue, absolute_object_attributes_predicate(x_darkblue, class_darkblue)), 
        Forall(x_green, absolute_object_attributes_predicate(x_green, class_green)),
        Forall(x_red, absolute_object_attributes_predicate(x_red, class_red)),
        Forall(x_babyblue, absolute_object_attributes_predicate(x_babyblue, class_babyblue)),
        Forall(x_grey, absolute_object_attributes_predicate(x_grey, class_grey)),
        Forall(x_lightblue, absolute_object_attributes_predicate(x_lightblue, class_lightblue)),
        Forall(x_circle, absolute_object_attributes_predicate(x_circle, class_circle)),
        Forall(x_rectangle, absolute_object_attributes_predicate(x_rectangle, class_rectangle)),
        
        # exclusivity axiom for shape - FIXED: No square brackets
        Forall(x, Not(And(absolute_object_attributes_predicate(x, class_circle), 
                          absolute_object_attributes_predicate(x, class_rectangle)))),
    ]

    # Add relative attribute cases only if we have valid pairs
    if len(valid_l_indices) > 0:
        axioms.extend([
            # FIXED: No square brackets
            Forall(ltn.diag(x_l_items, x_r_items), to_the_left_predicate(x_l_items)),
            Forall(ltn.diag(x_l_items, x_r_items), Not(to_the_left_predicate(x_r_items)))
        ])

    # exclusivity for colour - FIXED: No square brackets
    for combi in combis_colors_previous[::-1]: 
        axioms.append(Forall(x, Not(And(absolute_object_attributes_predicate(x, combi[0]), 
                                       absolute_object_attributes_predicate(x, combi[1])))))

    sat_level = And(*axioms)
    return sat_level.value
    
#-----------------------------------------------------------------------------------------
# Training loop with proper PyTorch tensors
optimizer = torch.optim.Adam([
    {'params': absolute_object_attributes_nn.parameters()},
    {'params': to_the_left_nn.parameters()}
], lr=0.001)

#-----------------------------------------------------------------------------------------
# Now try to create the predicates again
absolute_object_attributes_nn = CNN_simple(8) 
absolute_object_attributes_predicate = ltn.Predicate(absolute_object_attributes_nn)

to_the_left_nn = Simple_keras_with_concatentation_left_of()
to_the_left_predicate = ltn.Predicate(to_the_left_nn)

print("SUCCESS: Models created with LTN predicates!")
#-----------------------------------------------------------------------------------------
# Test the axioms
for img_index, img_features, labels_shape, labels_color, location_feature in ds_train: 
    print("Initial sat level %.5f" % axioms(img_index, img_features, labels_shape, labels_color, location_feature))
    break

#-----------------------------------------------------------------------------------------



